package com.nhnacademy;

public interface Breakable {
    public int getLifeCount();
    public void setLifeCount(int lifeCount);
    public void breakDown();
}
