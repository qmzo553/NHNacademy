package com.nhnacademy;

public class OutOfRangeException extends RuntimeException{
    
}