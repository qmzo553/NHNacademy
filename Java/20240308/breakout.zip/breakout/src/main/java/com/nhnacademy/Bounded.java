package com.nhnacademy;

public interface Bounded {
    public void bounce(Regionable other);
}
