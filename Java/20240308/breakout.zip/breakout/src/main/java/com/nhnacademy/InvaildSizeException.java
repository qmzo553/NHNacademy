package com.nhnacademy;

public class InvaildSizeException extends RuntimeException{
    
}
